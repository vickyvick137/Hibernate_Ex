package com.lti.assignment.Bank;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="bank")
public class Bank {
	
	private long id;
	private String bname;
	
	private Set<Customer> customers;
	
	public Bank() {
		
	}
	
	
public Bank(String bname) {
		super();
		this.bname = bname;
	}


@Id
@Column(name="bank_id")
@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="somesequenceName2")
@SequenceGenerator(name="somesequenceName2",sequenceName="bank1",allocationSize=1)
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getBname() {
		return bname;
	}

	public void setBname(String bname) {
		this.bname = bname;
	}
@OneToMany(mappedBy="bank",cascade=CascadeType.ALL)
	public Set<Customer> getCustomers() {
		return customers;
	}

	public void setCustomers(Set<Customer> customers) {
		this.customers = customers;
	}

	@Override
	public String toString() {
		return "Bank [id=" + id + ", bname=" + bname + ", customers=" + customers + "]";
	}
	

}
