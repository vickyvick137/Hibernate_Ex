package com.lti.assignment.Bank;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="customer3")
public class Customer {
	private long id;
	private String cname;
	private String ccity;
	
	
	private Bank bank1;


	public Customer() {
		super();
	}


	public Customer(String cname, String ccity, Bank bank1) {
		super();
		this.cname = cname;
		this.ccity = ccity;
		this.bank1 = bank1;
	}

	@Id
	@Column(name="cid")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="somesequenceName2")
	@SequenceGenerator(name="somesequenceName2",sequenceName="cust",allocationSize=1)
	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}

@Column(name="cname")
	public String getCname() {
		return cname;
	}


	public void setCname(String cname) {
		this.cname = cname;
	}

@Column(name="ccity")
	public String getCcity() {
		return ccity;
	}


	public void setCcity(String ccity) {
		this.ccity = ccity;
	}

	@ManyToOne
	@JoinColumn(name="bank_id")
	public Bank getBank() {
		return bank1;
	}

	public void setBank(Bank bank1) {
		this.bank1 = bank1;
	}
	
	
}
